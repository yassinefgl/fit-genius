import 'package:flutter/material.dart';

class TipsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tips'),
      ),
      body: Center(
        child: Text(
          'Here are some tips...',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
