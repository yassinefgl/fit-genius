import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LunchScreen(),
    );
  }
}

class LunchScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: Icon(Icons.arrow_back, color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  'LUNCH TIME',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                  hintText: 'Search...',
                  suffixIcon: Icon(Icons.search),
                ),
              ),
            ),
            SectionTitle(title: 'Meat Treats'),
            HorizontalList(items: [
              CategoryItem(title: 'Seafood', imagePath: 'assets/seafood.jpg'),
              CategoryItem(title: 'Chicken', imagePath: 'assets/chicken.jpg'),
              CategoryItem(title: 'Beef', imagePath: 'assets/beef.jpg'),
              CategoryItem(title: 'Turkey', imagePath: 'assets/turkey.jpg'),
              CategoryItem(title: 'Fish', imagePath: 'assets/fish.jpg'),
            ]),
            BannerImage(imagePath: 'assets/coffee_ad.jpg'),
            SectionTitle(title: 'Special Occasion'),
            HorizontalList(items: [
              CategoryItem(title: 'Summer Food', imagePath: 'assets/summer_food.jpg'),
              CategoryItem(title: 'Weekend Night', imagePath: 'assets/weekend_night.jpg'),
              CategoryItem(title: 'Party Time', imagePath: 'assets/party_time.jpg'),
              CategoryItem(title: 'Special Collection', imagePath: 'assets/special_collection.jpg'),
            ]),
            SectionTitle(title: 'Sugar Free'),
            HorizontalList(items: [
              CategoryItem(title: 'Ice cream', imagePath: 'assets/ice_cream.jpg'),
              CategoryItem(title: 'Cake', imagePath: 'assets/cake.jpg'),
              CategoryItem(title: 'Appetizing Dessert', imagePath: 'assets/appetizing_dessert.jpg'),
              CategoryItem(title: 'Special Collection', imagePath: 'assets/special_collection.jpg'),
            ]),
            SectionTitle(title: 'Delight Meal'),
            HorizontalList(items: [
              CategoryItem(title: 'Soupe', imagePath: 'assets/soupe.jpg'),
              CategoryItem(title: 'Pasta', imagePath: 'assets/pasta.jpg'),
              CategoryItem(title: 'Stir Fry', imagePath: 'assets/stir_fry.jpg'),
              CategoryItem(title: 'Fresh Dishes', imagePath: 'assets/fresh_dishes.jpg'),
            ]),
            SectionTitle(title: 'Immunity Booster'),
            HorizontalList(items: [
              CategoryItem(title: 'Detox', imagePath: 'assets/detox.jpg'),
              CategoryItem(title: 'Salad', imagePath: 'assets/salad.jpg'),
              CategoryItem(title: 'Vegan', imagePath: 'assets/vegan.jpg'),
            ]),
            BannerImage(imagePath: 'assets/lunch_box.jpg'),
            SectionTitle(title: 'Diabetic Premium'),
            HorizontalList(items: [
              CategoryItem(title: 'Find your meal', imagePath: 'assets/find_meal.jpg'),
              CategoryItem(title: 'You can collect and print', imagePath: 'assets/collect_print.jpg'),
            ]),
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;

  SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Text(
        title,
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class HorizontalList extends StatelessWidget {
  final List<CategoryItem> items;

  HorizontalList({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150, // Définir une hauteur pour la liste horizontale
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.asset(
                    items[index].imagePath,
                    height: 100,
                    width: 100,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  items[index].title,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class CategoryItem {
  final String title;
  final String imagePath;

  CategoryItem({required this.title, required this.imagePath});
}

class BannerImage extends StatelessWidget {
  final String imagePath;

  BannerImage({required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Image.asset(imagePath),
    );
  }
}
