import 'package:flutter/material.dart';


class BreakfastScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown.shade200,
        leading: Icon(Icons.arrow_back, color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Header(),
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: 2,
              childAspectRatio: 0.8,
              padding: EdgeInsets.all(8.0),
              crossAxisSpacing: 8.0,
              mainAxisSpacing: 8.0,
              children: [
                buildMenuItem('Egg', 'assets/egg.jpg'),
                buildMenuItem('Pancakes', 'assets/pancakes.jpg'),
                buildMenuItem('Waffles', 'assets/waffles.jpg'),
                buildMenuItem('Toast', 'assets/toast.jpg'),
                buildMenuItem('Smoothie Bowl', 'assets/smoothie_bowl.jpg'),
                buildMenuItem('Oatmeal', 'assets/oatmeal.jpg'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget buildMenuItem(String title, String imagePath) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20.0),
          child: Image.asset(
            imagePath,
            fit: BoxFit.cover,
            width: 150,
            height: 150,
          ),
        ),
        SizedBox(height: 8.0),
        Text(
          title,
          style: TextStyle(
            fontSize: 16.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}

class Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Image.asset(
          'assets/breakfast_header.jpg',
          fit: BoxFit.cover,
          width: double.infinity,
          height: 150,
        ),
        Container(
          color: Colors.brown.shade100,
          padding: EdgeInsets.all(16.0),
          child: Column(
            children: [
              Text(
                'Start your day with a delicious breakfast!',
                style: TextStyle(
                  fontSize: 20.0,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
              Icon(Icons.coffee, size: 40, color: Colors.brown),
            ],
          ),
        ),
      ],
    );
  }
}