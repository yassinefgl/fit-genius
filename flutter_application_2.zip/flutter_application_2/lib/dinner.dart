import 'package:flutter/material.dart';


class DinnerMenuScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dinner on you Tonight'),
        backgroundColor: Colors.purple[200],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {},
        ),
      ),
      body: Container(
        color: Colors.purple[50],
        child: SingleChildScrollView(
          child: Column(
            children: [
              HeaderSection(),
              MenuItem(
                title: 'Rice',
                imagePath: 'assets/images/rice.jpg',
                description: 'Rice is great if you want to eat a 100 of something',
              ),
              MenuItem(
                title: 'Salad',
                imagePath: 'assets/images/salad.jpg',
                description: 'Eat clean and green',
              ),
              MenuItem(
                title: 'Quinoa',
                imagePath: 'assets/images/quinoa.jpg',
                description: 'Everything is better with Quinoa',
              ),
              MenuItem(
                title: 'Soup',
                imagePath: 'assets/images/soup.jpg',
                description: 'Good soup is one of the prime ingredients of a good living',
              ),
              MenuItem(
                title: 'Pasta',
                imagePath: 'assets/images/pasta.jpg',
                description: 'Life is a Combination between magic and pasta',
              ),
              MenuItem(
                title: 'Noodles',
                imagePath: 'assets/images/noodles.jpg',
                description: 'Noodles are not only amusing but delicious',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HeaderSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Text(
            'Dinner on you Tonight',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.red,
            ),
          ),
          SizedBox(height: 10),
          Image.asset('assets/images/header_decoration.png'), // Assume you have a decorative image
        ],
      ),
    );
  }
}

class MenuItem extends StatelessWidget {
  final String title;
  final String imagePath;
  final String description;

  MenuItem({required this.title, required this.imagePath, required this.description});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.purple,
            ),
          ),
          SizedBox(height: 5),
          Row(
            children: [
              GestureDetector(
                onTap: () {
                  // Handle image button click
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Clicked on $title')),
                  );
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.asset(
                    imagePath,
                    width: 100,
                    height: 100,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  description,
                  style: TextStyle(
                    fontSize: 16,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 10),
          Divider(color: Colors.purple),
        ],
      ),
    );
  }
}
