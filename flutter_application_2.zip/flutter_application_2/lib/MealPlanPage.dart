import 'package:flutter/material.dart';
import 'breakfast.dart';
import 'lunch.dart';
import 'dinner.dart';
import 'snacks.dart';


class MealPlanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              color: Color.fromARGB(255, 210, 96, 14),
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    'Meal Plan',
                    style: TextStyle(
                      fontFamily: 'Cursive',
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.brown[900],
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Discover the most delicious and healthy meals',
                    style: TextStyle(
                      fontFamily: 'Cursive',
                      fontSize: 16,
                      color: Colors.brown[700],
                    ),
                  ),
                  SizedBox(height: 16),
                  _buildMealButton(context, 'Breakfast', 'assets/breakfast.jpg', BreakfastScreen()),
                  _buildMealButton(context, 'Lunch', 'assets/lunch.jpg', LunchScreen()),
                  _buildMealButton(context, 'Dinner', 'assets/dinner.jpg', DinnerMenuScreen()),
                  _buildMealButton(context, 'Snack', 'assets/snack.jpg', SnacksScreen()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMealButton(BuildContext context, String text, String imagePath, Widget? destination) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      child: ElevatedButton(
        onPressed: destination != null
            ? () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => destination),
                );
              }
            : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          padding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: Ink(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(imagePath),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(
                Colors.black.withOpacity(0.6),
                BlendMode.darken,
              ),
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 16),
            alignment: Alignment.center,
            child: Text(
              text,
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
