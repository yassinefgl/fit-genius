import 'package:flutter/material.dart';


class SnacksScreen extends StatelessWidget {
  final List<Map<String, String>> snacks = [
    {
      'image': 'assets/page1.png',
      'title': 'Top High-Protein Snacks',
    },
    {
      'image': 'assets/page2.png',
      'title': 'Top High-Fiber Snacks',
    },
    {
      'image': 'assets/page3.png',
      'title': 'Best aliments for diabetic people',
    },
    {
      'image': 'assets/page4.png',
      'title': 'Aliments to avoid for diabetic people',
    },
    // Ajoutez plus d'items ici
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Diaporama Horizontal'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Snacks',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Being offered a snack can be beneficial in stabilizing your blood sugar. Here are several healthy snack ideas you might consider, in consultation with a registered dietitian to complement your diabetes-friendly eating plan.',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: snacks.length,
                itemBuilder: (context, index) {
                  return SnackCard(
                    image: snacks[index]['image']!,
                    title: snacks[index]['title']!,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SnackCard extends StatelessWidget {
  final String image;
  final String title;

  const SnackCard({
    required this.image,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200,
      margin: EdgeInsets.only(right: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.asset(
              image,
              height: 200,
              width: 200,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 8),
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}